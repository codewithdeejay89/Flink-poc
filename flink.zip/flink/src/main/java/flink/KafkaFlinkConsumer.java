package flink;

import java.util.Properties;

import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

public class KafkaFlinkConsumer {
    public static void main(String[] args) throws Exception {
        // Set up the execution environment
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironment();

        // Set Kafka properties
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        properties.setProperty("group.id", "flink-group");

        // Create a Kafka Consumer
        FlinkKafkaConsumer<String> kafkaConsumer = new FlinkKafkaConsumer<>(
            "example",                        // topic name
            new SimpleStringSchema(),          // deserialization schema
            properties                         // Kafka properties
        );

        // Consume messages from Kafka topic
        DataStream<String> kafkaStream = env.addSource(kafkaConsumer);

        // Print received messages to console
        kafkaStream.print();

        // Execute the Flink job
        //env.execute("Flink Kafka Consumer Example");
    }
}
