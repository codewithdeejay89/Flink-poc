package flink;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.configuration.Configuration;

public class App {

    public static void main(String[] args) throws Exception {
        // Set up the execution environment
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // Create a data stream of numbers from 1 to 50
        // Create a data stream of numbers from 1 to 50 (Long type)
        DataStreamSource<Long> numbers = env.fromSequence(1, 50);

        // Introduce a delay of 2 seconds between each count
        numbers
            .map(new RichMapFunction<Long, Long>() {
                @Override
                public void open(Configuration parameters) throws Exception {
                    super.open(parameters);
                }

                @Override
                public Long map(Long value) throws Exception {
                    // Delay of 2 seconds between each number
                    Thread.sleep(2000);
                    return value;
                }
            })
            .print(); // Print each number to the console

        // Execute the Flink job
        env.execute("Count from 1 to 50 every 2 seconds");
    }
}
